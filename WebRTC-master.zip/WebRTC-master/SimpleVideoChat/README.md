### Simple WebRTC-based Video Chat Web Application
A simple Audio/Video Chat Web Application implemented by using WebRTC and WebSockets for signaling purposes.

### Documentation
This application is accompanied by a tutorial, available on our [web-engineering.info](http://web-engineering.info/node/57) blog.

### License
This application and all the resources are available under [MIT License](https://opensource.org/licenses/MIT).
